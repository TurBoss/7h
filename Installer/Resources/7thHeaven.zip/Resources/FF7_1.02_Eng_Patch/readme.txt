Instructions:

By default this patch will extract to the Desktop.  You need to copy both FF7Config.exe and Final Fantasy 7.exe to the directory on the hard drive that the game is installed to. (Usually c:\program files\square soft\final fantasy. Before you run the game you need to run the Final Fantasy 7 Configuration and select the Graphics configuration tab. Check the Riva box that is below the Resolution area of the dialogue box. Set the Display to Primary Display. Render to 3D hardware.  Finally, click the OK box to save the settings.

Known Problems:

After installing the patch you receive the error; 'Missing file GRU32.DLL'   You will need to download the OpenGL Dynamic Link Libraries for Windows 95.  You can find them at http://babeard.simplenet.com/dll.html.  The files you need are GRU32.ZIP and glide.zip.  Unzip these files in your c:\windows\system directory.

If you have other problems with the game, after installing the patch please send e-mail to techsupp@eidos.com with the subject of Final Fantasy 7.  You can also call our Technical Support in the U.S. at 415-547-1244.  Our office hours are 9:00 a.m. to 5:00 p.m. pacific time, Monday through Friday.
